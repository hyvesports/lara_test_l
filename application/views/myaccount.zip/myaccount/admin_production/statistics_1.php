<?php 
$makeDate=date("d-m-Y", strtotime($this->session->userdata('date_now')));
$DesignQtyCount=$this->dashboard_model->get_wo_total_counts_by_stage_design($makeDate,'4','Design');
$DesignQcQtyCount=$this->dashboard_model->get_wo_total_counts_by_stage($makeDate,'11','Design');
$PrintingQtyCount=$this->dashboard_model->get_wo_total_counts_by_stage($makeDate,'5','Printing');
$BundlingQtyCount=$this->dashboard_model->get_wo_total_counts_by_stage($makeDate,'6','Fusing');
$FusingQtyCount=$this->dashboard_model->get_wo_total_counts_by_fusing($makeDate,'6','Fusing');
$StitchingQtyCount=$this->dashboard_model->get_wo_total_counts_by_stitching($makeDate,'8','Stitching');
$FincalQcQtyCount=$this->dashboard_model->get_wo_total_counts_by_stage($makeDate,'5','stitching');
$dispatchQtyCount=$this->dashboard_model->get_dispatch_done_total($makeDate);


$totalQtyArray=$this->dashboard_model->get_wo_total_qty_count($makeDate);
$stitchingQtyCount=$this->dashboard_model->get_wo_total_stitching($makeDate);
$stitchingOrderCount=$this->dashboard_model->get_wo_total_stitching_orders($makeDate);
$stitchingOfflineOrderCount=$this->dashboard_model->get_wo_total_stitching_orders_by_type($makeDate,1);
$stitchingOnlineOrderCount=$this->dashboard_model->get_wo_total_stitching_orders_by_type($makeDate,2);

$stitchingAvgCount=$this->dashboard_model->get_wo_total_stitching_orders_avg($makeDate);



$qcRejArray=$this->dashboard_model->get_design_qc_rejected($makeDate);
    $bundlingRejArray=$this->dashboard_model->get_design_bundling_rejected($makeDate);
$finalqcRejArray=$this->dashboard_model->get_design_final_qc_rejected($makeDate);

$offlineOrderCnt=0;

$onlineOrderCnt=0;$printingOrderCnt=0;$fusingOrderCnt=0;
$total_qty_count=0;
$finalqcOrderCount=0;$bundlingOrderCnt=0;$stitchingOrderCNT=0;$dispatchOrderCnt=0;
$d_count=0;$t_count=0;$qcRejQty=0;$bqcRej=0;$fnlQcRej=0;
$design_count=0;
$design_qc_count=0;

if($qcRejArray)
{
    foreach($qcRejArray as $dqcR)
                          {

$qcRejQty +=$dqcR['qty'];
}
}

if($bundlingRejArray)
{
    foreach($bundlingRejArray as $qcR)
                          {

$bqcRej +=$qcR['qty'];
}
}

if($finalqcRejArray)
{
    foreach($finalqcRejArray as $fcR)
                          {

$fnlQcRej +=$fcR['qty'];
}
}

if($stitchingOfflineOrderCount['cnt']!=""){

	$offlineOrderCnt=$stitchingOfflineOrderCount['cnt'];
}
if($DesignQtyCount['cnt']!=""){

$design_count=$DesignQtyCount['cnt'];
}
if($FincalQcQtyCount['cnt']!=""){

$fusingOrderCnt=$FincalQcQtyCount['cnt'];
}

if($dispatchQtyCount['cnt']!=""){

$dispatchOrderCnt=$dispatchQtyCount['cnt'];
}


if($DesignQcQtyCount['cnt']!=""){

$design_qc_count=$DesignQcQtyCount['cnt'];
}
if($StitchingQtyCount['cnt']!=""){

$stitchingOrderCNT=$StitchingQtyCount['cnt'];
}
if($FusingQtyCount['cnt']!=""){

$fusingOrderCnt=$FusingQtyCount['cnt'];
}

if($BundlingQtyCount['cnt']!=""){

$bundlingOrderCnt=$BundlingQtyCount['cnt'];
}


if($PrintingQtyCount['cnt']!=""){

$printingOrderCnt=$PrintingQtyCount['cnt'];
}


if($stitchingOnlineOrderCount['cnt']!=""){
$onlineOrderCnt=$stitchingOnlineOrderCount['cnt'];
}




if($stitchingQtyCount['qty']!=""){
$d_count=$stitchingQtyCount['qty'];
}
if($stitchingOrderCount['cnt']!=""){
$t_count=$stitchingOrderCount['cnt'];
}

if($totalQtyArray['qty']!=""){
$total_qty_count=$totalQtyArray['qty'];
}

?>
<div class="row">
  <div class="col-md-3 grid-margin">
    <div class="card">
      <div class="card-body">
	<h4 class="card-title mb-0">Totql Qty</h4>
	<div class="d-flex justify-content-between align-items-center">
	  <div class="d-inline-block pt-3">
	    <div class="d-md-flex">
	      <h2 class="mb-0"><?php echo $total_qty_count;?>  </h2>
	    </div>
	  </div>

	</div>
      </div>
    </div>
  </div>

  <div class="col-md-3 grid-margin">
    <div class="card">
      <div class="card-body">
	<h4 class="card-title mb-0">Total Orders</h4>
	<div class="d-flex justify-content-between align-items-center">
	  <div class="d-inline-block pt-3">
	    <div class="d-md-flex">
	      <h2 class="mb-0"><?php echo $total_qty_count;?>   </h2>
	    </div>

	  </div>

	</div>
      </div>
    </div>
  </div>

  <div class="col-md-2 grid-margin">
    <div class="card">
      <div class="card-body">
	<h4 class="card-title mb-0">Offline Orders</h4>
	<div class="d-flex justify-content-between align-items-center">
	  <div class="d-inline-block pt-3">
	    <div class="d-md-flex">
	      <h2 class="mb-0"><?php echo $offlineOrderCnt;?>  </h2>
	    </div>
	  </div>

	</div>
      </div>
    </div>
  </div>

  <div class="col-md-2 grid-margin">
    <div class="card">
      <div class="card-body">
	<h4 class="card-title mb-0">Online Orders</h4>
	<div class="d-flex justify-content-between align-items-center">
	  <div class="d-inline-block pt-3">
	    <div class="d-md-flex">
	      <h2 class="mb-0"><?php echo $onlineOrderCnt;?> </h2>
	    </div>
	  </div>

	</div>
      </div>
    </div>
  </div>

  <div class="col-md-2 grid-margin">
    <div class="card">
      <div class="card-body">
	<h4 class="card-title mb-0">Average</h4>
	<div class="d-flex justify-content-between align-items-center">
	  <div class="d-inline-block pt-3">
	    <div class="d-md-flex">
	      <h2 class="mb-0"><?php echo $stitchingAvgCount;?>  </h2>
	    </div>
	  </div>
	  
	</div>
      </div>
    </div>
  </div>
</div>


<div class="row">	
  <div class="col-md-12 grid-margin stretch-card">
  <div class="col-md-3 grid-margin">
    <div class="card">
      <div class="card-body">
	<h4 class="card-title mb-0">Design</h4>
	<div class="d-flex justify-content-between align-items-center">
	  <div class="d-inline-block pt-3">
	    <div class="d-md-flex">
	      <h2 class="mb-0"><?php echo $design_count;?>  </h2>
	    </div>
	  </div>

	</div>
      </div>
    </div>
  </div>

  <div class="col-md-3 grid-margin">
    <div class="card">
      <div class="card-body">
	<h4 class="card-title mb-0">Design Qc</h4>
	<div class="d-flex justify-content-between align-items-center">
	  <div class="d-inline-block pt-3">
	    <div class="d-md-flex">
	      <h2 class="mb-0"><?php echo $design_qc_count;?>   </h2>
	    </div>
	  </div>

	</div>
      </div>
    </div>
  </div>

  <div class="col-md-3 grid-margin">
    <div class="card">
      <div class="card-body">
	<h4 class="card-title mb-0">Printing</h4>
	<div class="d-flex justify-content-between align-items-center">
	  <div class="d-inline-block pt-3">
	    <div class="d-md-flex">
	      <h2 class="mb-0"><?php echo $printingOrderCnt;?>   </h2>
	    </div>
	  </div>

	</div>
      </div>
    </div>
  </div>

  <div class="col-md-3 grid-margin">
    <div class="card">
      <div class="card-body">
	<h4 class="card-title mb-0">Fusing</h4>
	<div class="d-flex justify-content-between align-items-center">
	  <div class="d-inline-block pt-3">
	    <div class="d-md-flex">
	      <h2 class="mb-0"><?php echo $fusingOrderCnt;?> </h2>
	    </div>
	  </div>

	</div>
      </div>
    </div>
  </div>

  </div>
</div>

<div class="row">
  <div class="col-md-12 grid-margin stretch-card">
  <div class="col-md-3 grid-margin">
    <div class="card">
      <div class="card-body">
	<h4 class="card-title mb-0">Bundling Qc</h4>
	<div class="d-flex justify-content-between align-items-center">
	  <div class="d-inline-block pt-3">
	    <div class="d-md-flex">
	      <h2 class="mb-0"><?php echo $bundlingOrderCnt;?> </h2>
	    </div>

	  </div>

	</div>
      </div>
    </div>
  </div>

  <div class="col-md-3 grid-margin">
    <div class="card">
      <div class="card-body">
	<h4 class="card-title mb-0">Stitching</h4>
	<div class="d-flex justify-content-between align-items-center">
	  <div class="d-inline-block pt-3">
	    <div class="d-md-flex">
	      <h2 class="mb-0"><?php echo $stitchingOrderCNT;?>  
	    </div>

	  </div>

	</div>
      </div>
    </div>
  </div>

  <div class="col-md-3 grid-margin">
    <div class="card">
      <div class="card-body">
	<h4 class="card-title mb-0">Final Qc</h4>
	<div class="d-flex justify-content-between align-items-center">
	  <div class="d-inline-block pt-3">
	    <div class="d-md-flex">
	      <h2 class="mb-0"><?php echo $fusingOrderCnt;?> </h2>
	    </div>
	  </div>

	</div>
      </div>
    </div>
  </div>

  <div class="col-md-3 grid-margin">
    <div class="card">
      <div class="card-body">
	<h4 class="card-title mb-0">Dispatch</h4>
	<div class="d-flex justify-content-between align-items-center">
	  <div class="d-inline-block pt-3">
	    <div class="d-md-flex">
	      <h2 class="mb-0"><?php echo $dispatchOrderCnt;?>   </h2>
	    </div>
	  </div>

	</div>
      </div>
    </div>
  </div>

  </div>
</div>

  





  





<script>
(function($) {
'use strict';
$(function() {
$('.listing').DataTable({
"aLengthMenu": [
[5, 10, 15, -1],
[5, 10, 15, "All"]
],
"iDisplayLength": 5,
"language": {
search: ""
}
});
$('.listing').each(function() {
var datatable = $(this);
// SEARCH - Add the placeholder for Search and Turn this into in-line form control
var search_input = datatable.closest('.dataTables_wrapper').find('div[id$=_filter] input');
search_input.attr('placeholder', 'Search');
search_input.removeClass('form-control-sm');
// LENGTH - Inline-Form control
var length_sel = datatable.closest('.dataTables_wrapper').find('div[id$=_length] select');
length_sel.removeClass('form-control-sm');
});
});
})(jQuery);
</script>
